# project1
MVP:
Application's target audience: This application targets user's who are interested in learning more about specific, real-time stock prices and news for various companies.
Problem this application solves: Having to bounce around from site to site to find information about a company's worth can be tiresome and repetitive. With stock information and news all in the same place-- users just have to search for a company and all information is displayed immediately. Problems solved within the application: Want to compare companies quickly? The recent searches portion of this application allows users to bounce back to previous searches quickly.
Absolute Minimum Functionality: 
Users will be able to search and pull stock price information for any given company and will be displayed visually  
Users will be able to search and pull news articles and topics for any give company
Users will be able to see when market is closing
User will be able to view their top 5 recent searches

 
